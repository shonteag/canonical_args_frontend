"""

"""
from __future__ import absolute_import



def nest_dict(flat_dict, sep='_'):
    """Return nested dict by splitting the keys on a delimiter.

    >>> from pprint import pprint
    >>> pprint(nest_dict({'title': 'foo', 'author_name': 'stretch',
    ... 'author_zipcode': '06901'}))
    {'author': {'name': 'stretch', 'zipcode': '06901'}, 'title': 'foo'}
    """
    tree = {}
    for key, val in flat_dict.items():
        t = tree

        prev = None
        prevtype = None
        for part in key.split(sep):

            parttype = None
            if "[]" in part:
                part = part.replace("[]", "")
                parttype = "list"

            elif "TYPE" in part:
                split = part.split("TYPE")
                part = split[0]
                parttpe = split[1]

            elif "KEY" in part:
                # this is a dict key
                pass

            elif "VALUE" in part:
                # this is a dict value
                pass

            elif "{typeselector}" in part:
                # do not insert it, just acts as type
                # for an entry
                part = None

            if prev is not None:
                t = t.setdefault(prev, {})
            prev = part
            prevtype = parttype
        else:
            if prevtype == "list":
                pass

            elif prevtype == "dict":
                pass
            else:
                val = val[0]

            t.setdefault(prev, val)
    return tree


if __name__ == "__main__":
    from pprint import pprint
    fmt = {'args-arg1KEY[]': [u'key1', u'key2'], 'args-arg1VALUE[]': [u'abc', u'1'], 'args-arg1{typeselector}': [u'str', u'int']}
    pprint(nest_dict(fmt, "-"))