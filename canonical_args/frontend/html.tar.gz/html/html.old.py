"""
Generate HTML frontend ``<form>`` code to match an arg spec.
"""
from __future__ import absolute_import

from canonical_args import check
from jinja2 import Environment, PackageLoader, select_autoescape



env = Environment(
	    loader=PackageLoader('canonical_args.frontend.html', 'template'),
	    autoescape=select_autoescape(['html', 'xml'])
	)

def generate_html(spec):

	def recurse(code, level, name, substruct, include_header=True):

		if isinstance(substruct, dict):
			# should always be dict,
			# so now check the type
			subtype = check.eval_subtype(substruct["type"])

			if isinstance(subtype, check.ChoiceOfOne):
				options = []
				entries = []

				for onetype in subtype:
					options.append(check.type_to_string(onetype))
					subvalues = substruct["values"]\
						[check.type_to_string(onetype)]
					subname = name+"-"+check.type_to_string(onetype)

					subcode = recurse("",
									  level+1,
									  name,
									  {"type": onetype,
									   "values": subvalues,
									   "name": subname
									  },
									  include_header=False)

					subtemplate = env.get_template(
						"hidden_div_choice_of_one.html")
					entries.append(
						subtemplate.render(name=subname,
										   entries=subcode,
										   groupname=name))

				subtemplate = env.get_template("entry_ChoiceOfOne.html")
				subcode = subtemplate.render(name=name,
										  	 options=options,
										  	 entries=entries)

				if include_header:
					subtemplate = env.get_template("entry.html")
					return subtemplate.render(name=name, entries=subcode)
				return subcode

			if isinstance(subtype, check.StructuredList):
				# structured list
				subcode = ""

				for i, t in enumerate(subtype):
					subcode += recurse(code, level+1, name+"-"+str(i), {
							"name": name+"-"+str(i),
							"type": t,
							"values": substruct["values"][i]
						}, include_header=False)

					if include_header:
						subcode += "<br />"

				if not include_header:
					subtemplate = env.get_template("entry_table.html")
					return subtemplate.render(name=name, entries=subcode)
				else:
					subtemplate = env.get_template("entry.html")
					return subtemplate.render(name=name, entries=subcode)
				return subcode

			elif subtype == dict and isinstance(substruct["values"], dict):
				# structured dict
				subcode = ""

				for key, value in substruct["values"].items():

					subcode += recurse(code,
									   level+1,
									   name+"-"+key,
									   value,
									   include_header=False)

				if not include_header:
					subtemplate = env.get_template("entry_table.html")
					return subtemplate.render(name=name, entries=subcode)
				else:
					subtemplate = env.get_template("entry.html")
					return subtemplate.render(name=name, entries=subcode)

			elif subtype == dict:
				# unstructured dict
				subcode = ""

				subtemplate = env.get_template(
					"unstructured_dict_input.html")
				subcode = subtemplate.render(name=name,
											 subname=name.split("-")[-1])

				if include_header:
					subtemplate = env.get_template("entry.html")
					return subtemplate.render(name=name, entries=subcode)
				return subcode

			elif subtype == list:
				# unstructured list
				subtemplate = env.get_template(
					"unstructured_list_input.html")
				subcode = subtemplate.render(name=name,
										     subname=name.split("-")[-1])
				
				if include_header:
					subtemplate = env.get_template("entry.html")
					return subtemplate.render(name=name, entries=subcode)
				return subcode

			elif subtype == check.NoneType:
				# NoneType
				subtemplate = env.get_template(
					"native_type_null.html")
				subcode = subtemplate.render(name=name,
											 subname=name.split("-")[-1])

				if include_header:
					subtemplate = env.get_template("entry.html")
					return subtemplate.render(name=name, entries=subcode)
				return subcode

			else:
				# base type entry (native)
				if isinstance(substruct["values"], list):
					# selector, not input
					subtemplate = env.get_template(
						"native_type_selector_input.html")

				else:
					subtemplate = env.get_template("native_type_input.html")
				
				comment = "No help available for this item."
				if "comment" in substruct:
					comment = substruct["comment"]

				subcode = subtemplate.render(name=name,
								   		     subname=name.split("-")[-1],
								   		     type=check.type_to_string(
								   		     	substruct["type"]),
								   		     values=substruct["values"],
								   		     comment=comment)

				if include_header:
					subtemplate = env.get_template("entry.html")
					return subtemplate.render(name=name, entries=subcode)
				return subcode


		elif isinstance(substruct, list):
			# list of arguments
			for i, value in enumerate(substruct):
				code += recurse(code, level+1, name+"-"+str(i), value)
			subtemplate = env.get_template("entry.html")
			return subtemplate.render(name=name, entries=code)

		return code



	if isinstance(spec, list):
		code = recurse("", 0, "args", spec)

	elif isinstance(spec, dict):
		code = ""
		for k, v in spec.items():
			code += recurse("", 0, k, v)
		subtemplate = env.get_template("entry.html")
		code = subtemplate.render(name="kwargs", entries=code)

	return code

def html_from_argspec(argspec):
	"""

	"""
	code = ""
	code += generate_html(argspec["args"])
	code += generate_html(argspec["kwargs"])

	template = env.get_template("top.html")
	return template.render(entries=code)

def set_template_env(template_module_path):
	"""

	"""
	import sys

	toppath = ".".join(x for x in template_module_path.split(".")[:-1])
	templates = template_module_path.split(".")[-1]

	setattr(sys.modules[__name__], "env", Environment(
	    loader=PackageLoader(toppath, templates),
	    autoescape=select_autoescape(['html', 'xml'])
	))
