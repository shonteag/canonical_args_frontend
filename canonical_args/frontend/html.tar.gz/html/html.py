"""
Generate HTML frontend ``<form>`` code to match an arg spec.
"""
from __future__ import absolute_import

from canonical_args import check
from jinja2 import Environment, PackageLoader, select_autoescape



env = Environment(
	    loader=PackageLoader('canonical_args.frontend.html', 'new_templates'),
	    autoescape=select_autoescape(['html', 'xml'])
	)

def get_display_name(name):
	return name.split("-")[-1]

def generate_html(spec):

	def recurse(entries, level, name, substruct, display_name=None):
		"""
		:param list entries: a list of dicts
		"""
		if display_name is None:
			display_name = name
		print "  "*level+str(level), name, substruct, "\n"

		subtype = check.eval_subtype(substruct["type"])

		html = ""

		if isinstance(subtype, check.ChoiceOfOne):
			# choice of one
			# recurse
			entries = []
			for index, subsubtype in enumerate(subtype):
				substring = check.type_to_string(subsubtype)
				inner_ = recurse([], level+1, name+"TYPE"+substring,
					{
						"name": name+"TYPE"+substring,
						"type": subsubtype,
						"values": substruct["values"][substring]
					})
				template = env.get_template("level.html")
				inner_ = template.render(name=name,
										 inner=inner_,
										 include_header=True)
				template = env.get_template("type_one_entry_div.html")
				inner_ = template.render(entries=inner_,
										 name=name+"-"+substring,
										 groupname=name)
				entries.append(inner_)

			template = env.get_template("type_one.html")
			html = template.render(name=name,
								   options=map(check.type_to_string, subtype),
								   entries=entries)

		elif subtype == list:
			# unstructured list
			# recurse
			template = env.get_template("type_unstructured_list.html")
			html = template.render(name=name)

		elif isinstance(subtype, check.StructuredList):
			# structured list
			# recurse
			for index, subsubtype in enumerate(subtype):
				print "recursing:", index, subsubtype
				html += recurse([], level+1, name+"["+str(index)+"]",
								{
									"name": name+"["+str(index)+"]",
									"type": subsubtype,
									"values": substruct["values"][index]
								})

			# template = env.get_template("table.html")
			# html = template.render(inner=html)
			# catch all html and wrap it in level-wrapper
			if level > 0:
				template = env.get_template("level.html")
				html = template.render(name=name,
									   inner=html,
									   include_header=True)

		elif subtype == dict and substruct["values"] is None:
			# unstructured dict
			# recurse
			template = env.get_template("type_unstructured_dict.html")
			html = template.render(name=name)

		elif subtype == dict and isinstance(substruct["values"], dict):
			# structured dict
			# recurse
			for key, value in substruct["values"].items():
				html += recurse([], level+1, name+"-"+key, value)

			if level > 0:
				template = env.get_template("level.html")
				html = template.render(name=name,
									   inner=html,
									   include_header=True)

		elif subtype == check.NoneType:
			# NoneType
			template = env.get_template("input_nontype.html")
			html = template.render(name=name)

		elif subtype == check.TypeType:
			# TypeType
			pass

		elif isinstance(substruct["values"], list):
			# Select box for value
			template = env.get_template("input_selector.html")
			html = template.render(name=name,
								   values=substruct["values"],
								   type=substruct["type"])

		else:
			# native type
			template = env.get_template("base_input.html")
			html = template.render(name=name,
								   type=check.type_to_string(substruct["type"]),
								   values=substruct["values"])

		return html


	html = ""
	for index, arg in enumerate(spec["args"]):
		subhtml = recurse([], 0, "args-"+arg["name"], arg)
		template = env.get_template("level.html")
		html += template.render(name=arg["name"],
								inner=subhtml,
								include_header=True)

	for kwarg, arg in spec["kwargs"].items():
		subhtml = recurse([], 0, "kwargs-"+kwarg, arg)
		template = env.get_template("level.html")
		html += template.render(name=kwarg, inner=subhtml, include_header=True)


	template = env.get_template("top.html")
	html = template.render(inner=html)
	return html

		
def html_from_argspec(argspec):
	"""

	"""
	code = ""
	code += generate_html(argspec["args"])
	code += generate_html(argspec["kwargs"])

	template = env.get_template("top.html")
	return template.render(entries=code)

def set_template_env(template_module_path):
	"""

	"""
	import sys

	toppath = ".".join(x for x in template_module_path.split(".")[:-1])
	templates = template_module_path.split(".")[-1]

	setattr(sys.modules[__name__], "env", Environment(
	    loader=PackageLoader(toppath, templates),
	    autoescape=select_autoescape(['html', 'xml'])
	))
